# Aufgabe 1 Summe

# Zwei Zahlen eingeben.
zahl_1 = int(input('Geben Sie eine erste ganze Zahl ein: '))
zahl_2 = int(input('Geben Sie eine zweite ganze Zahl ein: '))

# Berechnete Summe ausgeben.
print(f'Die Summe der beiden Zahlen {zahl_1} und {zahl_2} ist {zahl_1 + zahl_2}')



